{{- if len .Values.global.site.domains -}}
1. Change your DNS records to point {{ index .Values.global.site.domains 0 }} at the ingress
controller endpoints
2. Contact Hubelia so they can add the certificate and DNS entries

3. Once Confirmed, Visit the site at:
    http://{{ index .Values.global.site.domains 0 }}

3. That's it!
{{- end -}}
